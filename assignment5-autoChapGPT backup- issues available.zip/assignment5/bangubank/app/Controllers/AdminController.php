<?php

namespace Bangubank\Controllers;

use Bangubank\Models\AdminUser;
use Bangubank\Models\UserManager as User;

class AdminController
{
    private $user;
    private $adminUser;
    private $filePath;

    public function __construct()
    {
        session_start();
        $this->user = new User();
        $this->adminUser = new AdminUser(__DIR__ . '/../../storage/users.json');

        // Set the path to the users.json file
        $this->user->filePath = __DIR__ . '/../../storage/users.json';
    }

    public function checkAdminLoggedIn()
    {
        if (!$this->adminUser->adminLoggedIn()) {
            header('Location: /app/Views/customer/dashboard.php');
            exit;
        }
    }
}
